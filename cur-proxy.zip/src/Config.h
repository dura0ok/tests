#pragma once

#include <cstdio>

inline constexpr size_t CHUNK_SIZE = BUFSIZ;
inline constexpr size_t MAX_EVENTS = 1;